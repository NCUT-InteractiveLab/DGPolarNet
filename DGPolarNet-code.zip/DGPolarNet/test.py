from random import *
s=''
for i in range(20):
    n = randint(0,100)
    s+=str(n)
    s+=" "

print(s)