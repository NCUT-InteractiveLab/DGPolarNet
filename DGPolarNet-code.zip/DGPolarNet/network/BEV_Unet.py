#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from dropblock import DropBlock2D


class BEV_Unet(nn.Module):
    # print("my_my_network")
    def __init__(self, n_class, n_height, dilation=1, group_conv=False, input_batch_norm=False, dropout=0.,
                 circular_padding=False, dropblock=True):
        # print("my init")
        super(BEV_Unet, self).__init__()
        self.n_class = n_class
        self.n_height = n_height
        self.network = UNet(n_class * n_height, n_height, dilation, group_conv, input_batch_norm, dropout,
                            circular_padding, dropblock)  #608 32 1 False True 0.5 True True
        # print("mei yi ge")
        # print(n_class * n_height, n_height, dilation, group_conv, input_batch_norm, dropout,
        #                     circular_padding, dropblock)
        # self.myconv = nn.Conv2d(32,256,kernel_size=1,bias=False)
    def forward(self, x):
        # print("my_forward")
        # print("my_x is")
        # print(list(x.size()))
        # x = self.myconv(x)
        # print("myconv finish")
        x = self.network(x)
        # print("yesyes")
        x = x.permute(0, 2, 3, 1)
        new_shape = list(x.size())[:3] + [self.n_height, self.n_class]
        # print("new_shape:")
        # print(new_shape)
        x = x.view(new_shape)
        # print("x.view:")
        # print(x)
        x = x.permute(0, 4, 1, 2, 3)
        # print("x.permute:")
        # print(x)

        return x


# 新加begin


def knn(x, k):  # 修改成fps
    inner = -2 * torch.matmul(x.transpose(2, 1), x)
    xx = torch.sum(x ** 2, dim=1, keepdim=True)
    pairwise_distance = -xx - inner - xx.transpose(2, 1)

    idx = pairwise_distance.topk(k=k, dim=-1)[1]  # (batch_size, num_points, k)
    return idx


def get_graph_feature(x, k=20, idx=None):
    batch_size = x.size(0)
    num_points = x.size(2)
    x = x.view(batch_size, -1, num_points)
    # print("x is:")
    # print(x)
    if idx is None:
        idx = knn(x, k=k)  # (batch_size, num_points, k)
        # print("idx is:",idx)
    device = torch.device('cuda')
    # print("idx finish")
    idx_base = torch.arange(0, batch_size, device=device).view(-1, 1, 1) * num_points
    # print("idx_base")
    idx = idx + idx_base

    idx = idx.view(-1)

    _, num_dims, _ = x.size()

    x = x.transpose(2,
                    1).contiguous()  # (batch_size, num_points, num_dims)  -> (batch_size*num_points, num_dims) #   batch_size * num_points * k + range(0, batch_size*num_points)
    # print("feanture begin")
    # feature = x.view(batch_size * num_points, -1)[idx, :]
    # feature = feature.view(batch_size, num_points, k, num_dims)
    x = x.view(batch_size, num_points, 1, num_dims).repeat(1, 1, k, 1)

    # feature = torch.cat((feature - x, x), dim=3).permute(0, 3, 1, 2).contiguous()
    # print("feature is:",feature)
    return x


# 新加end


class UNet(nn.Module):
    # print("my unet")
    def __init__(self, n_class, n_height, dilation, group_conv, input_batch_norm, dropout, circular_padding, dropblock):
        super(UNet, self).__init__()
        self.inc = inconv(n_height, 64, dilation, input_batch_norm, circular_padding)
        self.down1 = down(64, 128, dilation, group_conv, circular_padding)
        self.down2 = down(128, 256, dilation, group_conv, circular_padding)
        self.down3 = down(256, 512, dilation, group_conv, circular_padding)
        self.down4 = down(512, 512, dilation, group_conv, circular_padding)
        self.up1 = up(1024, 256, circular_padding, group_conv=group_conv, use_dropblock=dropblock, drop_p=dropout)
        self.up2 = up(512, 128, circular_padding, group_conv=group_conv, use_dropblock=dropblock, drop_p=dropout)
        self.up3 = up(256, 64, circular_padding, group_conv=group_conv, use_dropblock=dropblock, drop_p=dropout)
        self.up4 = up(128, 64, circular_padding, group_conv=group_conv, use_dropblock=dropblock, drop_p=dropout)

        self.outc = outconv(64, n_class)

        self.bn1 = nn.BatchNorm2d(64)
        self.bn2 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(256)
        self.bn5 = nn.BatchNorm2d(512)
        self.conv1 = nn.Sequential(nn.Conv2d(6, 64, kernel_size=1, bias=False),
                                   self.bn1,
                                   nn.LeakyReLU(negative_slope=0.2))
        self.conv2 = nn.Sequential(nn.Conv2d(64, 64, kernel_size=1, bias=False),
                                   self.bn2,
                                   nn.LeakyReLU(negative_slope=0.2))
        self.conv3 = nn.Sequential(nn.Conv2d(64 * 2, 128, kernel_size=1, bias=False),
                                   self.bn3,
                                   nn.LeakyReLU(negative_slope=0.2))
        self.conv4 = nn.Sequential(nn.Conv2d(128 * 2, 256, kernel_size=1, bias=False),
                                   self.bn4,
                                   nn.LeakyReLU(negative_slope=0.2))

        self.conv5 = nn.Sequential(nn.Conv1d(512, 1024, kernel_size=1, bias=False),
                                   self.bn5,
                                   nn.LeakyReLU(negative_slope=0.2))

        # self.myconv2 = nn.Conv2d(4,3,kernel_size=1,bias=False)
        self.myconv1 = nn.Conv2d(480,64,kernel_size=1,bias=False)
        self.myconv2 = nn.Conv2d(120,256,kernel_size=1,bias=False)
        self.dropout = nn.Dropout(p=0. if dropblock else dropout)

    def forward(self, x):
        x1 = self.inc(x)
        # print("inc finish")
        x = get_graph_feature(x1, k=20)
        # print("get_feature finish")
        x = self.myconv1(x)
        x = self.conv2(x)
        # print("conv2 finish")
        # x1 = x.max(dim=-1, keepdim=False)[0]
        # print("x.max finish")
        x2 = self.down1(x1)
        # print("donw1 finish")
        x = get_graph_feature(x2, k=20)

        # print("This x is:",x)
        # print("get_feature2")
        # x = torch.unsqueeze(x,0)
        # print("myconv1")
        x = self.conv3(x2)
        # x = torch.squeeze(x,dim=0)
        # print("get_feature2_end")
        # x2 = x.max(dim=-1, keepdim=False)[0]

        x3 = self.down2(x2)

        # print("get_feature3")
        x = get_graph_feature(x3, k=20)
        x = self.myconv2(x)
        # print("myconv2 finish")
        x = self.conv4(x3)
        # print("conv4 finish")

        x4 = self.down3(x3)

        # x=get_graph_feature(x4,k=20)
        # x =self.conv5

        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        x = self.outc(self.dropout(x))
        return x


class double_conv(nn.Module):
    # print("my double_conv")
    '''(conv => BN => ReLU) * 2'''

    def __init__(self, in_ch, out_ch, group_conv, dilation=1):
        super(double_conv, self).__init__()
        if group_conv:
            self.conv = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 3, padding=1, groups=min(out_ch, in_ch)),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True),
                nn.Conv2d(out_ch, out_ch, 3, padding=1, groups=out_ch),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )
        else:
            self.conv = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 3, padding=1),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True),
                nn.Conv2d(out_ch, out_ch, 3, padding=1),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )

    def forward(self, x):
        x = self.conv(x)
        return x


class double_conv_circular(nn.Module):
    '''(conv => BN => ReLU) * 2'''

    # print("my double_conv_circular")
    def __init__(self, in_ch, out_ch, group_conv, dilation=1):
        # print("double_conv_circular")
        super(double_conv_circular, self).__init__()
        if group_conv:
            self.conv1 = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 3, padding=(1, 0), groups=min(out_ch, in_ch)),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )
            self.conv2 = nn.Sequential(
                nn.Conv2d(out_ch, out_ch, 3, padding=(1, 0), groups=out_ch),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )
        else:
            self.conv1 = nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 3, padding=(1, 0)),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )
            self.conv2 = nn.Sequential(
                nn.Conv2d(out_ch, out_ch, 3, padding=(1, 0)),
                nn.BatchNorm2d(out_ch),
                nn.LeakyReLU(inplace=True)
            )

    def forward(self, x):
        # add circular padding
        x = F.pad(x, (1, 1, 0, 0), mode='circular')
        x = self.conv1(x)
        x = F.pad(x, (1, 1, 0, 0), mode='circular')
        x = self.conv2(x)
        return x


class inconv(nn.Module):
    # print("my inconv")
    def __init__(self, in_ch, out_ch, dilation, input_batch_norm, circular_padding):
        super(inconv, self).__init__()
        if input_batch_norm:
            if circular_padding:
                self.conv = nn.Sequential(
                    nn.BatchNorm2d(in_ch),
                    double_conv_circular(in_ch, out_ch, group_conv=False, dilation=dilation)
                )
            else:
                self.conv = nn.Sequential(
                    nn.BatchNorm2d(in_ch),
                    double_conv(in_ch, out_ch, group_conv=False, dilation=dilation)
                )
        else:
            if circular_padding:
                self.conv = double_conv_circular(in_ch, out_ch, group_conv=False, dilation=dilation)
            else:
                self.conv = double_conv(in_ch, out_ch, group_conv=False, dilation=dilation)

    def forward(self, x):
        x = self.conv(x)
        return x


class down(nn.Module):
    # print("my down")
    def __init__(self, in_ch, out_ch, dilation, group_conv, circular_padding):
        super(down, self).__init__()
        if circular_padding:
            self.mpconv = nn.Sequential(
                nn.MaxPool2d(2),
                double_conv_circular(in_ch, out_ch, group_conv=group_conv, dilation=dilation)
            )
        else:
            self.mpconv = nn.Sequential(
                nn.MaxPool2d(2),
                double_conv(in_ch, out_ch, group_conv=group_conv, dilation=dilation)
            )

    def forward(self, x):
        x = self.mpconv(x)
        return x


class up(nn.Module):
    # print("my up")
    def __init__(self, in_ch, out_ch, circular_padding, bilinear=True, group_conv=False, use_dropblock=False,
                 drop_p=0.5):
        super(up, self).__init__()

        #  would be a nice idea if the upsampling could be learned too,
        #  but my machine do not have enough memory to handle all those weights
        if bilinear:
            self.up = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True)
        elif group_conv:
            self.up = nn.ConvTranspose2d(in_ch // 2, in_ch // 2, 2, stride=2, groups=in_ch // 2)
        else:
            self.up = nn.ConvTranspose2d(in_ch // 2, in_ch // 2, 2, stride=2)

        if circular_padding:
            self.conv = double_conv_circular(in_ch, out_ch, group_conv=group_conv)
        else:
            self.conv = double_conv(in_ch, out_ch, group_conv=group_conv)

        self.use_dropblock = use_dropblock
        if self.use_dropblock:
            self.dropblock = DropBlock2D(block_size=7, drop_prob=drop_p)

    def forward(self, x1, x2):
        x1 = self.up(x1)

        # input is CHW
        diffY = x2.size()[2] - x1.size()[2]
        diffX = x2.size()[3] - x1.size()[3]

        x1 = F.pad(x1, (diffX // 2, diffX - diffX // 2,
                        diffY // 2, diffY - diffY // 2))

        # for padding issues, see
        # https://github.com/HaiyongJiang/U-Net-Pytorch-Unstructured-Buggy/commit/0e854509c2cea854e247a9c615f175f76fbb2e3a
        # https://github.com/xiaopeng-liao/Pytorch-UNet/commit/8ebac70e633bac59fc22bb5195e513d5832fb3bd

        x = torch.cat([x2, x1], dim=1)
        x = self.conv(x)
        if self.use_dropblock:
            x = self.dropblock(x)
        return x


class outconv(nn.Module):
    # print("my outconv")
    def __init__(self, in_ch, out_ch):
        super(outconv, self).__init__()
        self.conv = nn.Conv2d(in_ch, out_ch, 1)

    def forward(self, x):
        x = self.conv(x)
        return x